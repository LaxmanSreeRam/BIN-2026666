import React, { useEffect, useRef } from 'react';
import { isLand } from '../utils/earthLandMask';

interface EarthGlobeProps {
  /** Speeds the globe up (used while the portal boot sequence runs). */
  boost?: boolean;
  className?: string;
}

// Muscat, Oman — same coordinates shown in the gate HUD.
const MUSCAT = { lat: 23.59, lon: 58.54 };
const DEG = Math.PI / 180;
const TILT = 22 * DEG; // how far we look down on the northern hemisphere
const CYAN = '94, 242, 255';
const VIOLET = '157, 123, 255';

interface Dots {
  x: Float32Array; // unit-sphere base vector (x,y,z) per dot
  y: Float32Array;
  z: Float32Array;
  count: number;
}

/** Evenly spaced dots over the sphere, kept only where there is land. */
function buildLandDots(stepDeg: number): Dots {
  const xs: number[] = [];
  const ys: number[] = [];
  const zs: number[] = [];
  for (let lat = -88; lat <= 88; lat += stepDeg) {
    const cosLat = Math.cos(lat * DEG);
    const lonStep = stepDeg / Math.max(cosLat, 0.05);
    for (let lon = -180; lon < 180; lon += lonStep) {
      if (!isLand(lat, lon)) continue;
      xs.push(cosLat * Math.sin(lon * DEG));
      ys.push(Math.sin(lat * DEG));
      zs.push(cosLat * Math.cos(lon * DEG));
    }
  }
  return {
    x: Float32Array.from(xs),
    y: Float32Array.from(ys),
    z: Float32Array.from(zs),
    count: xs.length,
  };
}

export const EarthGlobe: React.FC<EarthGlobeProps> = ({ boost = false, className = '' }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const boostRef = useRef(boost);
  boostRef.current = boost;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dots = buildLandDots(1.6);
    const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;

    // Background stars (fixed positions in 0..1 space)
    const stars = Array.from({ length: 90 }, () => ({
      x: Math.random(),
      y: Math.random(),
      r: Math.random() * 1.2 + 0.3,
      p: Math.random() * Math.PI * 2,
    }));

    let w = 0;
    let h = 0;
    let dpr = 1;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = rect.width;
      h = rect.height;
      canvas.width = Math.max(1, Math.round(w * dpr));
      canvas.height = Math.max(1, Math.round(h * dpr));
    };
    resize();
    const ro = new ResizeObserver(() => {
      resize();
      if (reduceMotion) draw(0);
    });
    ro.observe(canvas);

    // Start with Muscat off to the left so it rolls into the centre.
    let rot = (MUSCAT.lon + 38) * DEG;
    let speedMul = 1;
    let scaleMul = 1;
    let last = performance.now();
    let raf = 0;

    const cosT = Math.cos(TILT);
    const sinT = Math.sin(TILT);

    function draw(time: number) {
      const c = ctx!;
      c.setTransform(dpr, 0, 0, dpr, 0, 0);
      c.clearRect(0, 0, w, h);

      const R = Math.min(w * 0.44, h * 0.43) * scaleMul;
      const cx = w / 2;
      const cy = h / 2;
      const cosA = Math.cos(rot);
      const sinA = Math.sin(rot);

      // Stars
      for (const s of stars) {
        const a = 0.25 + 0.35 * Math.sin(time / 900 + s.p);
        c.fillStyle = `rgba(255,255,255,${Math.max(0, a)})`;
        c.fillRect(s.x * w, s.y * h, s.r, s.r);
      }

      // Atmosphere glow (behind the sphere)
      const glow = c.createRadialGradient(cx, cy, R * 0.92, cx, cy, R * 1.32);
      glow.addColorStop(0, `rgba(${CYAN}, 0.38)`);
      glow.addColorStop(0.35, `rgba(${CYAN}, 0.12)`);
      glow.addColorStop(0.7, `rgba(${VIOLET}, 0.06)`);
      glow.addColorStop(1, 'rgba(6, 9, 19, 0)');
      c.fillStyle = glow;
      c.beginPath();
      c.arc(cx, cy, R * 1.32, 0, Math.PI * 2);
      c.fill();

      // Orbit ring — back half first
      const ringRx = R * 1.38;
      const ringRy = R * 0.36;
      const ringRot = -16 * DEG;
      const ringPoint = (th: number) => {
        const ex = ringRx * Math.cos(th);
        const ey = ringRy * Math.sin(th);
        return {
          x: cx + ex * Math.cos(ringRot) - ey * Math.sin(ringRot),
          y: cy + ex * Math.sin(ringRot) + ey * Math.cos(ringRot),
        };
      };
      const strokeRing = (from: number, to: number, alpha: number) => {
        c.strokeStyle = `rgba(${CYAN}, ${alpha})`;
        c.lineWidth = 1;
        c.setLineDash([2, 6]);
        c.beginPath();
        for (let i = 0; i <= 80; i++) {
          const p = ringPoint(from + ((to - from) * i) / 80);
          if (i === 0) c.moveTo(p.x, p.y);
          else c.lineTo(p.x, p.y);
        }
        c.stroke();
        c.setLineDash([]);
      };
      strokeRing(Math.PI, Math.PI * 2, 0.16);

      // Sphere body
      const body = c.createRadialGradient(cx - R * 0.35, cy - R * 0.4, R * 0.1, cx, cy, R);
      body.addColorStop(0, 'rgba(24, 52, 92, 0.95)');
      body.addColorStop(0.55, 'rgba(10, 20, 46, 0.96)');
      body.addColorStop(1, 'rgba(5, 8, 20, 0.98)');
      c.fillStyle = body;
      c.beginPath();
      c.arc(cx, cy, R, 0, Math.PI * 2);
      c.fill();

      // Graticule (front side only)
      c.lineWidth = 0.6;
      const project = (vx: number, vy: number, vz: number) => {
        const x1 = vx * cosA - vz * sinA;
        const z1 = vx * sinA + vz * cosA;
        const y2 = vy * cosT - z1 * sinT;
        const z2 = vy * sinT + z1 * cosT;
        return { sx: cx + R * x1, sy: cy - R * y2, z: z2 };
      };
      c.strokeStyle = `rgba(${CYAN}, 0.13)`;
      for (let lat = -60; lat <= 60; lat += 30) {
        c.beginPath();
        let pen = false;
        for (let lon = -180; lon <= 180; lon += 4) {
          const cl = Math.cos(lat * DEG);
          const p = project(cl * Math.sin(lon * DEG), Math.sin(lat * DEG), cl * Math.cos(lon * DEG));
          if (p.z > 0) {
            if (!pen) c.moveTo(p.sx, p.sy);
            else c.lineTo(p.sx, p.sy);
            pen = true;
          } else pen = false;
        }
        c.stroke();
      }
      for (let lon = -180; lon < 180; lon += 30) {
        c.beginPath();
        let pen = false;
        for (let lat = -90; lat <= 90; lat += 4) {
          const cl = Math.cos(lat * DEG);
          const p = project(cl * Math.sin(lon * DEG), Math.sin(lat * DEG), cl * Math.cos(lon * DEG));
          if (p.z > 0) {
            if (!pen) c.moveTo(p.sx, p.sy);
            else c.lineTo(p.sx, p.sy);
            pen = true;
          } else pen = false;
        }
        c.stroke();
      }

      // Land dots: faint "see-through" back side, then bright front side
      const size = Math.max(1.2, R / 200);
      c.fillStyle = `rgba(${CYAN}, 0.07)`;
      for (let i = 0; i < dots.count; i++) {
        const p = project(dots.x[i], dots.y[i], dots.z[i]);
        if (p.z <= 0) c.fillRect(cx + (p.sx - cx) * 0.999, p.sy, size * 0.8, size * 0.8);
      }
      for (let i = 0; i < dots.count; i++) {
        const p = project(dots.x[i], dots.y[i], dots.z[i]);
        if (p.z <= 0) continue;
        const a = 0.35 + 0.65 * Math.pow(p.z, 0.55);
        c.fillStyle = p.z > 0.55 ? `rgba(160, 250, 255, ${a})` : `rgba(${CYAN}, ${a})`;
        const d = size * (0.7 + 0.6 * p.z);
        c.fillRect(p.sx - d / 2, p.sy - d / 2, d, d);
      }

      // Limb rim light
      const rim = c.createRadialGradient(cx, cy, R * 0.86, cx, cy, R * 1.01);
      rim.addColorStop(0, `rgba(${CYAN}, 0)`);
      rim.addColorStop(1, `rgba(${CYAN}, 0.45)`);
      c.fillStyle = rim;
      c.beginPath();
      c.arc(cx, cy, R * 1.01, 0, Math.PI * 2);
      c.fill();

      // Muscat marker
      const ml = Math.cos(MUSCAT.lat * DEG);
      const m = project(
        ml * Math.sin(MUSCAT.lon * DEG),
        Math.sin(MUSCAT.lat * DEG),
        ml * Math.cos(MUSCAT.lon * DEG)
      );
      if (m.z > 0.15) {
        const vis = Math.min(1, (m.z - 0.15) / 0.35);
        const pulse = (time / 1400) % 1;
        c.strokeStyle = `rgba(77, 255, 195, ${0.8 * (1 - pulse) * vis})`;
        c.lineWidth = 1.5;
        c.beginPath();
        c.arc(m.sx, m.sy, 4 + pulse * 22, 0, Math.PI * 2);
        c.stroke();
        c.fillStyle = `rgba(77, 255, 195, ${vis})`;
        c.shadowColor = '#4dffc3';
        c.shadowBlur = 14;
        c.beginPath();
        c.arc(m.sx, m.sy, 3.5, 0, Math.PI * 2);
        c.fill();
        c.shadowBlur = 0;

        // Label with leader line (hidden on small screens so it never covers the text)
        if (w >= 640) {
          const lx = m.sx + 22;
          const ly = m.sy - 26;
          c.strokeStyle = `rgba(77, 255, 195, ${0.7 * vis})`;
          c.lineWidth = 1;
          c.beginPath();
          c.moveTo(m.sx + 3, m.sy - 3);
          c.lineTo(lx, ly);
          c.lineTo(lx + 8, ly);
          c.stroke();
          c.font = '600 11px "JetBrains Mono", monospace';
          c.fillStyle = `rgba(255, 255, 255, ${vis})`;
          c.fillText('MUSCAT, OMAN', lx + 12, ly + 4);
          c.font = '500 10px "JetBrains Mono", monospace';
          c.fillStyle = `rgba(${CYAN}, ${0.9 * vis})`;
          c.fillText('23.59°N  58.54°E', lx + 12, ly + 17);
        }
      }

      // Orbit ring — front half + satellite
      strokeRing(0, Math.PI, 0.38);
      const sat = ((time / 7000) % 1) * Math.PI * 2;
      const sp = ringPoint(sat);
      const satFront = Math.sin(sat) > 0;
      const behindGlobe = !satFront && Math.hypot(sp.x - cx, sp.y - cy) < R;
      if (!behindGlobe) {
        c.fillStyle = '#ffffff';
        c.shadowColor = '#5ef2ff';
        c.shadowBlur = 12;
        c.beginPath();
        c.arc(sp.x, sp.y, 2.6, 0, Math.PI * 2);
        c.fill();
        c.shadowBlur = 0;
      }
    }

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const targetSpeed = boostRef.current ? 7 : 1;
      speedMul += (targetSpeed - speedMul) * Math.min(1, dt * 4);
      scaleMul += ((boostRef.current ? 1.1 : 1) - scaleMul) * Math.min(1, dt * 3);
      rot -= dt * 0.11 * speedMul; // west→east, like the real Earth
      draw(now);
      raf = requestAnimationFrame(frame);
    };

    if (reduceMotion) {
      rot = (MUSCAT.lon - 8) * DEG;
      draw(0);
    } else {
      raf = requestAnimationFrame(frame);
    }

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className={`absolute inset-0 w-full h-full pointer-events-none ${className}`}
    />
  );
};
