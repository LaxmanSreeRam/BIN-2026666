import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

/** Procedural, self-contained Earth globe so the gate does not depend on third-party texture hosts. */
export const EarthGlobe: React.FC = () => {
  const hostRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'high-performance' });
    } catch {
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(host.clientWidth, host.clientHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.setClearColor(0x000000, 0);
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(34, host.clientWidth / host.clientHeight, 0.1, 100);
    camera.position.z = 5.1;

    const globe = new THREE.Group();
    scene.add(globe);

    // Equirectangular procedural map: rich oceans, softly varied land, and cloud bands.
    const mapCanvas = document.createElement('canvas');
    mapCanvas.width = 2048;
    mapCanvas.height = 1024;
    const ctx = mapCanvas.getContext('2d');
    if (ctx) {
      const ocean = ctx.createLinearGradient(0, 0, 0, 1024);
      ocean.addColorStop(0, '#071c43'); ocean.addColorStop(0.45, '#0876a9'); ocean.addColorStop(1, '#03152e');
      ctx.fillStyle = ocean; ctx.fillRect(0, 0, 2048, 1024);
      // Subtle ocean currents and depth bands.
      for (let i = 0; i < 70; i++) {
        ctx.beginPath();
        const y = (i / 70) * 1024;
        ctx.strokeStyle = `rgba(95,220,255,${0.025 + (i % 4) * 0.008})`;
        ctx.lineWidth = 2 + (i % 3);
        ctx.moveTo(0, y);
        ctx.bezierCurveTo(500, y - 35, 1300, y + 40, 2048, y - 12);
        ctx.stroke();
      }
      const continents: Array<{ points: Array<[number, number]>; color: string }> = [
        { color: '#62a96b', points: [[170,190],[230,130],[330,105],[420,145],[455,205],[420,250],[385,295],[355,350],[310,380],[280,330],[240,285],[205,260]] },
        { color: '#4b995f', points: [[365,390],[425,405],[455,470],[440,555],[400,660],[365,735],[335,675],[315,590],[325,500]] },
        { color: '#77b86e', points: [[790,170],[850,135],[920,150],[965,195],[1030,205],[1080,250],[1055,290],[1000,300],[980,350],[920,330],[880,285],[835,265],[800,220]] },
        { color: '#5da96a', points: [[910,350],[985,340],[1035,395],[1050,470],[1015,550],[975,625],[940,580],[920,505],[885,430]] },
        { color: '#6aab70', points: [[1040,180],[1140,125],[1290,135],[1430,185],[1500,245],[1450,300],[1370,315],[1300,275],[1220,300],[1160,250],[1090,245]] },
        { color: '#4f9c64', points: [[1270,310],[1350,325],[1400,385],[1380,470],[1320,520],[1270,470],[1240,395]] },
        { color: '#7fb66f', points: [[1510,215],[1590,180],[1660,220],[1700,280],[1650,315],[1585,290]] },
        { color: '#c7d6c1', points: [[0,0],[2048,0],[2048,80],[1900,105],[1800,75],[1650,110],[1450,90],[1250,110],[1000,85],[750,115],[500,90],[250,120],[0,85]] },
        { color: '#d7e2d2', points: [[0,930],[230,900],[470,940],[700,910],[950,950],[1200,915],[1450,945],[1700,900],[1900,930],[2048,900],[2048,1024],[0,1024]] }
      ];
      continents.forEach(({ points, color }) => {
        ctx.beginPath(); points.forEach(([x,y], i) => i ? ctx.lineTo(x,y) : ctx.moveTo(x,y)); ctx.closePath();
        ctx.fillStyle = color; ctx.fill();
        ctx.strokeStyle = 'rgba(185,239,170,0.35)'; ctx.lineWidth = 5; ctx.stroke();
        // terrain speckle adds texture at globe scale
        const xs = points.map(p => p[0]), ys = points.map(p => p[1]);
        for (let j = 0; j < 220; j++) {
          const x = Math.min(...xs) + Math.random() * (Math.max(...xs) - Math.min(...xs));
          const y = Math.min(...ys) + Math.random() * (Math.max(...ys) - Math.min(...ys));
          ctx.fillStyle = j % 2 ? 'rgba(225,213,145,.10)' : 'rgba(20,75,55,.12)';
          ctx.fillRect(x, y, 2 + Math.random() * 6, 2 + Math.random() * 4);
        }
      });
      // Polar ice caps.
      const ice = ctx.createLinearGradient(0, 0, 0, 130); ice.addColorStop(0, '#f5ffff'); ice.addColorStop(1, 'rgba(220,248,255,0)');
      ctx.fillStyle = ice; ctx.fillRect(0, 0, 2048, 130);
      const southIce = ctx.createLinearGradient(0, 890, 0, 1024); southIce.addColorStop(0, 'rgba(220,248,255,0)'); southIce.addColorStop(1, '#e8fbff');
      ctx.fillStyle = southIce; ctx.fillRect(0, 890, 2048, 134);
    }

    const texture = new THREE.CanvasTexture(mapCanvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = renderer.capabilities.getMaxAnisotropy();
    const earth = new THREE.Mesh(
      new THREE.SphereGeometry(1.45, 96, 96),
      new THREE.MeshPhongMaterial({ map: texture, shininess: 22, specular: new THREE.Color('#4acfff') })
    );
    globe.add(earth);

    // Soft atmospheric rim and inner blue haze.
    const atmosphere = new THREE.Mesh(
      new THREE.SphereGeometry(1.51, 80, 80),
      new THREE.ShaderMaterial({
        vertexShader: `varying vec3 vNormal; varying vec3 vViewPosition; void main(){ vec4 mvPosition=modelViewMatrix*vec4(position,1.0); vNormal=normalize(normalMatrix*normal); vViewPosition=-mvPosition.xyz; gl_Position=projectionMatrix*mvPosition; }`,
        fragmentShader: `varying vec3 vNormal; varying vec3 vViewPosition; void main(){ float rim=pow(1.0-max(dot(normalize(vNormal),normalize(vViewPosition)),0.0),2.2); gl_FragColor=vec4(0.16,0.68,1.0,rim*0.62); }`,
        blending: THREE.AdditiveBlending, side: THREE.BackSide, transparent: true, depthWrite: false
      })
    );
    globe.add(atmosphere);

    scene.add(new THREE.AmbientLight(0x8dbbff, 1.0));
    const sun = new THREE.DirectionalLight(0xffffff, 2.6); sun.position.set(-3, 2, 4); scene.add(sun);
    const rimLight = new THREE.PointLight(0x26d9ff, 3, 10); rimLight.position.set(2, -1, -3); scene.add(rimLight);

    // Starfield.
    const starPositions = new Float32Array(1500 * 3);
    for (let i = 0; i < 1500; i++) {
      const radius = 7 + Math.random() * 13;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      starPositions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      starPositions[i * 3 + 1] = radius * Math.cos(phi);
      starPositions[i * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta);
    }
    const starGeometry = new THREE.BufferGeometry(); starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    const stars = new THREE.Points(starGeometry, new THREE.PointsMaterial({ color: 0xa9eaff, size: 0.025, transparent: true, opacity: 0.82 }));
    scene.add(stars);

    // Fine orbital rings.
    const orbitMaterial = new THREE.MeshBasicMaterial({ color: 0x55eaff, transparent: true, opacity: 0.28, side: THREE.DoubleSide });
    const orbit = new THREE.Mesh(new THREE.TorusGeometry(1.82, 0.004, 8, 220), orbitMaterial);
    orbit.rotation.x = 1.12; orbit.rotation.y = -0.3; globe.add(orbit);
    const orbit2 = new THREE.Mesh(new THREE.TorusGeometry(1.98, 0.003, 8, 220), new THREE.MeshBasicMaterial({ color: 0x9d7bff, transparent: true, opacity: 0.22, side: THREE.DoubleSide }));
    orbit2.rotation.x = 0.38; orbit2.rotation.y = 0.72; globe.add(orbit2);

    let frame = 0;
    let animationId = 0;
    const animate = () => {
      animationId = requestAnimationFrame(animate);
      globe.rotation.y += 0.0018;
      stars.rotation.y -= 0.00012;
      earth.rotation.y = 0.04;
      renderer.render(scene, camera);
      frame++;
    };
    animate();

    const resize = () => {
      if (!host) return;
      const width = Math.max(1, host.clientWidth), height = Math.max(1, host.clientHeight);
      camera.aspect = width / height; camera.updateProjectionMatrix(); renderer.setSize(width, height);
    };
    const observer = new ResizeObserver(resize); observer.observe(host);

    return () => {
      cancelAnimationFrame(animationId); observer.disconnect();
      scene.traverse((obj) => {
        if (obj instanceof THREE.Mesh || obj instanceof THREE.Points) {
          obj.geometry.dispose();
          const material = obj.material;
          if (Array.isArray(material)) material.forEach((m) => m.dispose()); else material.dispose();
        }
      });
      texture.dispose(); renderer.dispose();
      if (renderer.domElement.parentNode === host) host.removeChild(renderer.domElement);
    };
  }, []);

  return <div ref={hostRef} aria-label="Rotating three-dimensional Earth" role="img" className="absolute inset-0 h-full w-full pointer-events-none" />;
};
